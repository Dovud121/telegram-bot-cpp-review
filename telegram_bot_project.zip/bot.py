import telebot
import random

# Bot tokenini quyida o'z tokeningiz bilan almashtiring
TOKEN = 'YOUR_BOT_TOKEN'
bot = telebot.TeleBot(TOKEN)

# /start komandasi
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.send_message(message.chat.id, "Assalomu alaykum! Dars raqamini kiriting (1, 2 yoki 3):")

# Foydalanuvchi xabariga javob
@bot.message_handler(func=lambda message: True)
def send_task(message):
    try:
        lesson_number = int(message.text.strip())
        if lesson_number not in [1, 2, 3]:
            bot.send_message(message.chat.id, "Faqat 1, 2 yoki 3 ni kiriting.")
            return

        filename = f"lesson{lesson_number}.txt"
        with open(filename, "r", encoding="utf-8") as f:
            tasks = f.readlines()

        task = random.choice(tasks)
        bot.send_message(message.chat.id, f"📚 Dars {lesson_number} dan tasodifiy vazifa:

{task}")
    except:
        bot.send_message(message.chat.id, "Iltimos, to'g'ri dars raqamini kiriting (1, 2 yoki 3).")

bot.polling()