Telegram Botdan foydalanish yo'riqnomasi:

1. Fayllar:
   - lesson1.txt, lesson2.txt, lesson3.txt — har bir darsdagi vazifalar ro'yxati.
   - bot.py — botning asosiy kodi.

2. Qanday ishlatish:
   - Python 3 o'rnatilgan bo'lishi kerak.
   - `pip install pyTelegramBotAPI` orqali kerakli kutubxonani o'rnating.
   - `bot.py` faylini oching va `YOUR_BOT_TOKEN` o'rniga o'z Telegram bot tokeningizni yozing.
   - `lesson1.txt`, `lesson2.txt`, `lesson3.txt` fayllar bot.py bilan bir joyda tursin.
   - Terminalda `python bot.py` buyrug'ini bering.

3. Bot qanday ishlaydi:
   - Siz botga 1, 2 yoki 3 raqamini yuborasiz.
   - Bot shu darsdan tasodifiy bitta vazifani sizga yuboradi.

👉 Omad! Dasturlashni yanada qiziqarli qiling!